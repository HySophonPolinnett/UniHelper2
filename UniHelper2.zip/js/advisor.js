/* UniHelper advisor – three fixed questions (no free typing), two filters (Coursework, Time).
 * Rule-based and works offline, using the student's real degree audit and semester schedule.
 * Suggestions are shuffled a little each time (required courses still come first) so asking again gives fresh ideas. */
(function () {
  "use strict";
  const UH = window.UH, P = window.UHParse;
  const term = () => { const s = UH.S.schedule; return s && s.term ? s.term : "semester"; };
  const labelOf = (arr, k) => (arr.find((x) => x[0] === k) || [k, k])[1];

  UH.QUESTIONS = [["next", "What should I take next semester?"], ["graduate", "What do I need to graduate?"], ["plan", "Build my plan"]];

  function filterText(f) {
    const bits = [];
    if (f.group && f.group !== "all") bits.push(labelOf(UH.COURSEWORK, f.group));
    if (f.time && f.time !== "both") bits.push(labelOf(UH.TIMES, f.time).toLowerCase());
    return bits.length ? " (" + bits.join(", ") + ")" : "";
  }

  function remaining(f) {
    const S = UH.S, a = S.audit;
    const lines = [];
    P.GROUP_ORDER.forEach((k) => {
      const o = a.groups[k]; if (!o || k === "none") return;
      if (f.group && f.group !== "all" && k !== f.group) return;
      const rem = UH.groupRem(k);
      lines.push("• " + (P.GROUP_LABEL[k] || k) + ": " + (o.required != null ? (rem === 0 ? "complete ✓ (" + o.required + " credits)" : rem + " of " + o.required + " credits still to take") : o.done + " credits done (requirement not listed)"));
    });
    const tot = a.totalRequired, doneCr = a.checks ? a.checks.earnedSum : 0;
    const head = tot ? "You have completed " + doneCr + " of " + tot + " credits – " + Math.max(0, tot - doneCr) + " to go." : "Here is where you stand.";
    return { head, lines };
  }

  /* kind: "next" | "graduate" | "plan";  f: { group, time } */
  UH.advise = function (kind, f) {
    const S = UH.S; f = Object.assign({ group: "all", time: "both" }, f || {});
    if (!S.audit && !S.major) return { text: "I need your degree audit first. Go to the Start tab and upload it – then I can answer exactly.", goStart: true };
    const base = S.audit ? "Based on your degree audit" : "Based on " + UH.MAJORS[S.major].n + " (an estimate – upload your degree audit for exact results)";
    const sched = S.schedule ? " and the " + term() + " schedule" : "";
    if (f.time !== "both" && !S.schedule) return { text: "To filter by morning or afternoon I need the semester schedule. Upload it on the Start tab, or set Time to “Morning & afternoon”.", goStart: true };

    if (kind === "graduate") {
      if (!S.audit) return { text: "Upload your degree audit (Start tab) and I'll show exactly what you still need to graduate.", goStart: true };
      const r = remaining(f), c = UH.candidates();
      const left = c.all.filter((x) => UH.groupMatches(x.group, f.group) && x.status !== "inprogress");
      const show = left.slice(0, 8);
      let text = r.head + filterText(f) + "\n" + r.lines.join("\n");
      if (show.length) text += "\n\nCourses still on your list" + (f.group !== "all" ? " for " + labelOf(UH.COURSEWORK, f.group) : "") + (left.length > show.length ? " (first " + show.length + " of " + left.length + ")" : "") + ":";
      else text += "\n\nNo courses left to take in " + (f.group !== "all" ? labelOf(UH.COURSEWORK, f.group) : "your list") + ".";
      return { text, codes: show.map((x) => x.code) };
    }

    if (kind === "plan") {
      const plan = UH.autoPlan(f); UH.save();
      if (!plan.length) return { text: base + sched + filterText(f) + ": I couldn't fit any eligible courses without a time clash. Try a different filter or a higher credit target on the Start tab." };
      return { text: "I built a " + UH.planCredits() + "-credit plan" + filterText(f) + " (target " + S.credits + ", maximum " + UH.MAX_CREDITS + ") with no time clashes. Press “Build my plan” again for a different mix.", codes: plan.map((p) => p.code), goPlan: true };
    }

    // "next"
    const rec = UH.recommend(f, 6), c = UH.candidates();
    if (!rec.items.length) {
      let why = "I found no matching courses.";
      if (f.group !== "all" && S.audit && (!S.audit.groups[f.group] || UH.groupRem(f.group) <= 0) && !c.all.some((x) => x.group === f.group)) why = "Good news: nothing is left to take in " + labelOf(UH.COURSEWORK, f.group) + ", so you don't need more courses there.";
      else if (f.group !== "all" && c.gone.some((x) => x.group === f.group)) why = "The " + labelOf(UH.COURSEWORK, f.group).toLowerCase() + " course(s) you still need aren't offered in the " + term() + " schedule.";
      else if (f.group !== "all" && c.locked.some((x) => x.group === f.group)) why = "The " + labelOf(UH.COURSEWORK, f.group).toLowerCase() + " course(s) you still need require a prerequisite first – see “Not yet eligible” in the Courses tab.";
      else if (f.time !== "both") why = "No eligible course has a section in that time window. Try another time or coursework filter.";
      else if (c.locked.length) why = "Everything left needs a prerequisite first – see “Not yet eligible” in the Courses tab.";
      return { text: base + sched + filterText(f) + ": " + why };
    }
    const cr = rec.items.reduce((n, x) => n + x.c.cr, 0);
    let text = base + sched + filterText(f) + ", here " + (rec.items.length === 1 ? "is the best match" : "are " + rec.items.length + " courses worth taking next") + " (required courses first, electives last):";
    if (!S.schedule) text += "\nUpload the semester schedule to see which of these are actually offered.";
    return { text, codes: rec.items.map((x) => x.code), note: rec.pool <= 6 ? "Only " + rec.pool + " course" + (rec.pool === 1 ? "" : "s") + " match right now, so there is nothing else to show." : "" };
  };
})();
